package com.example.theimpostor;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Group_setting extends AppCompatActivity {

    Button Continue, go_back, play_dont_save, play_save, dont_play_save;
    EditText players_num, impostor_num, group_name, minutes;
    Dialog save_new_game_dialog;
    DBHelper dbHelper;
    Boolean update = false;
    String oldGroupname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_setting);

        getSupportActionBar().hide();

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(this.getResources().getColor(R.color.black));

        dbHelper = new DBHelper(this);

        players_num = findViewById(R.id.players_num);
        impostor_num = findViewById(R.id.impostor_num);
        group_name = findViewById(R.id.group_name);
        minutes = findViewById(R.id.minutes);
        Continue = findViewById(R.id.Continue);
        go_back = findViewById(R.id.go_back);


        Intent intent = getIntent();
        if (intent.hasExtra("i")) {
            update = true;
            ArrayList<Group> groups = new ArrayList<>();
            groups = dbHelper.getAllGroups();
            Group group = groups.get(Integer.parseInt(intent.getExtras().getString("i")));
            players_num.setText(Integer.toString(group.getPlayersnum()));
            impostor_num.setText(Integer.toString(group.getImpostornum()));
            minutes.setText(Integer.toString(group.getMinutes()));
            oldGroupname = group.getGroupname();
            group_name.setText(oldGroupname);
        }

        Continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check_input()){
                    Create_save_new_game_dialog();
                }
            }
        });

        go_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Group_setting.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public Boolean check_input (){
        if (group_name.getText().toString().matches("") || players_num.getText().toString().matches("") || impostor_num.getText().toString().matches("") || minutes.getText().toString().matches("")){
            Toast mytoast = new Toast(this);
            mytoast.setText("You did not enter all the details");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(players_num.getText().toString())<3){
            Toast mytoast = new Toast(this);
            mytoast.setText("number of players cannot be less than 3");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(players_num.getText().toString())>20){
            Toast mytoast = new Toast(this);
            mytoast.setText("number of players cannot be more than 20");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(impostor_num.getText().toString())<1){
            Toast mytoast = new Toast(this);
            mytoast.setText("There should be at least 1 impostor");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(impostor_num.getText().toString()) > Integer.parseInt(players_num.getText().toString())/3){
            Toast mytoast = new Toast(this);
            mytoast.setText("number of impostors cannot be more than " + Integer.parseInt(players_num.getText().toString())/3);
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(minutes.getText().toString()) <6){
            Toast mytoast = new Toast(this);
            mytoast.setText("number of minutes cannot be less than 6");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        if (Integer.parseInt(minutes.getText().toString()) > 12){
            Toast mytoast = new Toast(this);
            mytoast.setText("number of minutes cannot be more than 12");
            mytoast.setDuration(Toast.LENGTH_SHORT);
            mytoast.show();
            return false;
        }
        return true;
    }

    public void Create_save_new_game_dialog(){
        save_new_game_dialog = new Dialog(this);
        save_new_game_dialog.setContentView(R.layout.continue_layout);
        save_new_game_dialog.setTitle("");
        save_new_game_dialog.setCancelable(true);
        play_dont_save = save_new_game_dialog.findViewById(R.id.play_dont_save);
        play_save = save_new_game_dialog.findViewById(R.id.play_save);
        dont_play_save = save_new_game_dialog.findViewById(R.id.dont_play_save);

        play_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Group group = new Group(group_name.getText().toString(), Integer.parseInt(players_num.getText().toString()), Integer.parseInt(impostor_num.getText().toString()), Integer.parseInt(minutes.getText().toString()));
                if (update){
                    dbHelper.updateGroup(group, oldGroupname);
                }
                else {
                    dbHelper.insertNewGroup(group);
                }
                group.resetGroup();
                Intent intent = new Intent(Group_setting.this, Game.class);
                intent.putExtra("group", group);
                startActivity(intent);
                // start game :)
            }
        });

        play_dont_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Group group = new Group(group_name.getText().toString(), Integer.parseInt(players_num.getText().toString()), Integer.parseInt(impostor_num.getText().toString()), Integer.parseInt(minutes.getText().toString()));
                group.resetGroup();
                Intent intent = new Intent(Group_setting.this, Game.class);
                intent.putExtra("group", group);
                startActivity(intent);
                // start game :)
            }
        });

        dont_play_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Group group = new Group(group_name.getText().toString(), Integer.parseInt(players_num.getText().toString()), Integer.parseInt(impostor_num.getText().toString()), Integer.parseInt(minutes.getText().toString()));
                if (update){
                    dbHelper.updateGroup(group, oldGroupname);
                }
                else {
                    dbHelper.insertNewGroup(group);
                }
                Intent intent = new Intent(Group_setting.this, MainActivity.class);
                startActivity(intent);
            }
        });

        save_new_game_dialog.show();
    }
}