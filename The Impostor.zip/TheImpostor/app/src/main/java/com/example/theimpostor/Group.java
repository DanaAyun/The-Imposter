package com.example.theimpostor;

import android.content.Intent;

import java.io.Serializable;
import java.util.Random;

public class Group implements Serializable {

    String groupname;
    int playersnum;
    int impostornum;
    Player[] players;
    int minutes;
    String place;
    Place[] places;

    public Group (String groupname, int playersnum, int impostornum, int minutes){
        this.groupname = groupname;
        this.playersnum = playersnum;
        this.impostornum = impostornum;
        this.players = new Player[playersnum];
        this.minutes = minutes;
    }

    public String getGroupname() { return groupname; }

    public void setGroupname(String groupname) { this.groupname = groupname; }

    public int getPlayersnum() { return playersnum; }

    public void setPlayersnum(int playersnum) { this.playersnum = playersnum; }

    public int getImpostornum() { return impostornum; }

    public void setImpostornum(int impostornum) { this.impostornum = impostornum; }

    public String getPlace() { return place; }

    public void setPlace(String place) { this.place = place; }

    public int getMinutes() { return minutes; }

    public void setMinutes(int minutes) { this.minutes = minutes; }

    public void resetGroup (){
        Random random = new Random();
        this.places = new Place[]{new Place("Airplane"), new Place("Bank"), new Place("Casino"), new Place("Circus Tent"), new Place("Party"), new Place("Theater"), new Place("Spa"), new Place("Hospital"), new Place("Hotel"), new Place("Military Base"), new Place("Movie"), new Place("Train"), new Place("Pirate Ship"),  new Place("Space Station"),  new Place("Police Station"),  new Place("Restaurant"),  new Place("School"),  new Place("Supermarket"),  new Place("Zoo"),  new Place("Library")};
        place = places[random.nextInt(places.length)].getPlace_name();

        for(int i=0 ; i<players.length ; i++) {
            players[i] = new Player();
            players[i].setName("player " + (i+1));
            players[i].setImpostor(false);
        }

        int[] impostors = new int[this.impostornum];
        Boolean duplicate = true;
        while (duplicate){
            for(int i=0 ; i<impostors.length ; i++) {
                impostors[i] = random.nextInt(playersnum);
            }
            duplicate = false;
            for(int i = 0; i < impostors.length; i++){
                for(int j = i + 1; j < impostors.length; j++){
                    if(impostors[i] == impostors[j]){
                        duplicate = true;
                    }
                }
            }
        }
        for(int i=0 ; i<impostors.length ; i++) {
            players[impostors[i]].setImpostor(true);
        }
    }

    public void change_place() {
        Random random = new Random();
        boolean same = true;
        while (same) {
            String new_place = places[random.nextInt(places.length)].getPlace_name();
            if (place.equals(new_place) != true) {
                same = false;
                place = new_place;
            }
        }

        int clues_num = 10;
        while (clues_num != 0) {
            int i = random.nextInt(20);
            if (places[i].getPlace_name().equals(place) != true) {
                places[i].setClue(true);
                clues_num --;
            }
        }
    }
}
