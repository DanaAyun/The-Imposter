package com.example.theimpostor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import org.w3c.dom.Text;

import java.util.ArrayList;

public class Saved_group extends AppCompatActivity {

    Button go_back;
    LinearLayout dynamic;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saved_group);
        dbHelper = new DBHelper(this);

        getSupportActionBar().hide();

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(this.getResources().getColor(R.color.black));

        dynamic = findViewById(R.id.dynamic);

        ArrayList<Group> groups = new ArrayList<>();
        groups = dbHelper.getAllGroups();
        for(int i=0 ; i<groups.size() ; i++) {
            Group group = groups.get(i);
            dynamic.addView(createSavedGroup(group, i));
        }

        go_back = findViewById(R.id.go_back);
        go_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Saved_group.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }

    public RelativeLayout createSavedGroup(Group group, int i) {
        LayoutInflater vi = (LayoutInflater) getApplicationContext().getSystemService(this.LAYOUT_INFLATER_SERVICE);
        RelativeLayout saved_group_layout = (RelativeLayout) vi.inflate(R.layout.saved_group_layout, null);
        TextView group_name = saved_group_layout.findViewById(R.id.group_name);
        TextView players_num = saved_group_layout.findViewById(R.id.players_num);
        TextView impostor_num = saved_group_layout.findViewById(R.id.impostor_num);
        TextView minutes = saved_group_layout.findViewById(R.id.minutes);
        Button edit = saved_group_layout.findViewById(R.id.edit);
        Button play = saved_group_layout.findViewById(R.id.play);
        Button delete = saved_group_layout.findViewById(R.id.delete);

        group_name.setText(group_name.getText().toString() + group.groupname.toString());
        players_num.setText(players_num.getText().toString() + group.playersnum);
        impostor_num.setText(impostor_num.getText().toString() + group.impostornum);
        minutes.setText(minutes.getText().toString() + group.minutes);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Saved_group.this, Group_setting.class);
                intent.putExtra("i", Integer.toString(i));
                startActivity(intent);
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                group.resetGroup();
                Intent intent = new Intent(Saved_group.this, Game.class);
                intent.putExtra("group", group);
                startActivity(intent);
                // start game :)
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.deleteGroup(group);
                Intent intent = new Intent(Saved_group.this, Saved_group.class);
                startActivity(intent);
            }
        });

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);

        saved_group_layout.setLayoutParams(params);

        return saved_group_layout;
    }
}