package com.example.theimpostor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class GameOver extends AppCompatActivity {

    Button start_over, go_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        getSupportActionBar().hide();

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(this.getResources().getColor(R.color.black));

        start_over = findViewById(R.id.start_over);
        go_back = findViewById(R.id.go_back);

        go_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameOver.this, MainActivity.class);
                startActivity(intent);
            }
        });

        start_over.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent group_intent = getIntent();
                Group group = (Group)group_intent.getSerializableExtra("group");
                group.resetGroup();

                Intent intent = new Intent(GameOver.this, Game.class);
                intent.putExtra("group", group);
                startActivity(intent);
            }
        });
    }
}