package com.example.theimpostor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.concurrent.TimeUnit;

public class Game extends AppCompatActivity implements SensorEventListener {

    Group group;
    int player_turn;
    Boolean game_over;
    Boolean pass_b, next_player_b;
    TextView name_text;
    TextView info_text;
    Button next_player;
    Handler handler = new Handler();
    SensorManager sensorManager;
    Sensor sensor;
    Button placeslist, clue, changeplace;
    int change_place = 1;
    int clues = 2;
    Boolean got_clue;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pass_phone_layout);

        getSupportActionBar().hide();

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(this.getResources().getColor(R.color.black));

        Intent intent = getIntent();
        group = (Group)intent.getSerializableExtra("group");

        game_over = false;
        player_turn = 0;
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        setButtons();

        Thread myThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (game_over != true){
                    pass();
                    if (player_turn < group.players.length-1){
                        player_turn++;
                    }
                    else {
                        player_turn = 0;
                    }
                }
            }
        });
        myThread.start();

        Intent intent1 = new Intent(this, MainActivity.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent1 = PendingIntent.getActivity(this, 0, intent1, 0);

        createNotificationChannel();
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, "id");
        notification.setContentTitle("The game is on!");
        notification.setContentText("time left: " + group.minutes + ":00   |   click to end the game" );
        notification.setSmallIcon(R.drawable.impostor);
        notification.setPriority(Notification.PRIORITY_DEFAULT);
        notification.setContentIntent(pendingIntent1);
        notification.setAutoCancel(true);

        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(2, notification.build());

        new CountDownTimer((int)group.getMinutes()*1000*60, 1000){
            public void onTick(long millisUntilFinished){
                int minutes_left = (int) millisUntilFinished / 60000;
                int seconds_left = (int) (millisUntilFinished - minutes_left*60000)/1000;
                notification.setContentText("time left: " + minutes_left + ":" + seconds_left + "   |   click to end the game" );
                notificationManager.notify(2, notification.build());
            }
            public  void onFinish(){
                notificationManager.cancel(2);
                game_over = true;
                Intent intent = new Intent(Game.this, GameOver.class);
                intent.putExtra("group", group);
                startActivity(intent);
            }
        }.start();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float currentSensorValue = event.values[0];
        if (currentSensorValue <= 50){
            pass_b = true;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onResume(){
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void pass(){
        handler.post(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.pass_phone_layout);
            }
        });

        pass_b = false;

        while (pass_b != true){
            //wait
        }

        got_clue = true;

        handler.post(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.player_layout);
                name_text = findViewById(R.id.name_text);
                info_text = findViewById(R.id.info_text);
                next_player = findViewById(R.id.next_player);
                name_text.setText(group.players[player_turn].getName());
                LinearLayout layout = findViewById(R.id.buttons_layout);

                if(changeplace.getParent() != null) {
                    ((ViewGroup)changeplace.getParent()).removeView(changeplace);
                }
                if(placeslist.getParent() != null) {
                    ((ViewGroup)placeslist.getParent()).removeView(placeslist);
                }
                if(clue.getParent() != null) {
                    ((ViewGroup)clue.getParent()).removeView(clue);
                }

                if (group.players[player_turn].isImpostor() == true){
                    info_text.setText("impostor");
                    layout.addView(placeslist);
                    layout.addView(clue);
                }
                else{
                    info_text.setText(group.getPlace());
                    layout.addView(changeplace);
                }
            }
        });

        next_player_b = false;

        handler.post(new Runnable() {
            @Override
            public void run() {
                next_player.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        next_player_b = true;
                    }
                });              }
        });


        while (next_player_b != true) {
            // wait
        }
    }

    private void createNotificationChannel () {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notifications";
            String description = "this is notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("id", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void setButtons(){
        Random random = new Random();
        WorkManager workManager = WorkManager.getInstance(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int) convertDpToPixel(300, this), LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 20, 0, 0);

        placeslist = new Button(this);
        placeslist.setLayoutParams(params);
        placeslist.setText("list of places");
        placeslist.setBackgroundResource(R.drawable.green_color);
        placeslist.setTextSize(25);
        placeslist.setTextColor(Color.WHITE);

        placeslist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Create_places_list_dialog();
            }
        });

        clue = new Button(this);
        clue.setLayoutParams(params);
        clue.setText("get clue");
        clue.setBackgroundResource(R.drawable.green_color);
        clue.setTextSize(25);
        clue.setTextColor(Color.WHITE);

        clue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (clues != 0 || got_clue == false){
                    clues --;
                    clue();
                    got_clue = true;
                    Data.Builder data = new Data.Builder();
                    data.putString("type", "clue");
                    OneTimeWorkRequest oneTimeWorkRequest =
                            new OneTimeWorkRequest.Builder(Alarm_Worker.class)
                                    .setConstraints(Constraints.NONE)
                                    .setInitialDelay((random.nextInt(20)+20)*1000, TimeUnit.SECONDS)
                                    .addTag("clue")
                                    .setInputData(data.build())
                                    .build();
                    workManager.enqueue(oneTimeWorkRequest);
                    toast("You got a clue!");
                }
                else {
                    if (clues != 0) {
                        toast("You dont have any clues left");
                    }
                    else {
                        toast("You already got a clue this turn");
                    }
                }
            }
        });

        changeplace = new Button(this);
        changeplace.setLayoutParams(params);
        changeplace.setText("change place");
        changeplace.setBackgroundResource(R.drawable.green_color);
        changeplace.setTextSize(25);
        changeplace.setTextColor(Color.WHITE);

        changeplace.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View v) {
                if (change_place != 0) {
                    change_place --;
                    set_place();
                    toast("You changed the place!");
                }
                else {
                    toast("You already changed the place");
                }
            }
        });
    }

    public void toast(String string){
        Toast mytoast = new Toast(this);
        mytoast.setText(string);
        mytoast.setDuration(Toast.LENGTH_SHORT);
        mytoast.show();
    }

    public static float convertDpToPixel(float dp, Context context){
        return dp * ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public void Create_places_list_dialog() {
        Dialog places_list_dialog = new Dialog(this);
        LinearLayout places_list_layout = new LinearLayout(this);
        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
        places_list_layout.setLayoutParams(params);
        places_list_layout.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < group.places.length; i++) {
            TextView textView = new TextView(this);
            textView.setText(group.places[i].getPlace_name());
            textView.setTextColor(Color.BLACK);
            textView.setTextSize(15);
            if (group.places[i].getChecked() == true || group.places[i].getClue() == true) {
                textView.setPaintFlags(textView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            }
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView textView = (TextView) v;
                    int place_i = -1;
                    for (int i = 0; i < group.places.length; i++) {
                        if (group.places[i].getPlace_name().equals(((TextView) v).getText().toString())){
                            place_i = i;
                        }
                    }
                    if (place_i != -1) {
                        if (group.places[place_i].getChecked() == true) {
                            textView.setPaintFlags(textView.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                            group.places[place_i].setChecked(false);
                        }
                        else {
                            textView.setPaintFlags(textView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                            group.places[place_i].setChecked(true);
                        }
                    }
                }
            });
            places_list_layout.addView(textView);
        }
        places_list_dialog.setContentView(places_list_layout);
        places_list_dialog.setTitle("PLACES LIST");
        places_list_dialog.setCancelable(true);
        places_list_dialog.show();
    }

    public void clue(){
        Random random = new Random();
        int clues_num = 0;
        int clues_possible_num = group.places.length + 1;
        for (int i = 0 ; i < group.places.length ; i ++)
        {
            if (group.places[i].getChecked() == true || group.places[i].getClue() == true) {
                clues_possible_num --;
            }
        }

        Boolean find_clues_num = true;
        while (find_clues_num == true){
            clues_num = random.nextInt(3) + 1;
            if (clues_num < clues_possible_num){
                find_clues_num = false;
            }
        }

        while (clues_num != 0) {
            int i = random.nextInt(20);
            if (group.places[i].getChecked() == false && group.places[i].getClue() == false && group.places[i].getPlace_name().equals(group.place) != true) {
                group.places[i].setClue(true);
                clues_num --;
            }
        }
    }

    public void set_place(){
        Random random = new Random();
        new CountDownTimer((random.nextInt(20)+20)*1000, 100){
            public void onTick(long millisUntilFinished){
            }
            public void onFinish(){
                notify_place_changing();
                group.change_place();
            }
        }.start();
    }

    public void notify_place_changing(){
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, "id");
        notification.setContentTitle("THE PLACE HAS CHANGED");
        notification.setContentText("please pass the phone a full round");
        notification.setSmallIcon(R.drawable.impostor);
        notification.setWhen(System.currentTimeMillis());
        notification.setAutoCancel(true);
        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(4, notification.build());

        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        // Vibrate for 500 milliseconds
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(5000, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            //deprecated in API 26
            v.vibrate(6700);
        }
        MediaPlayer alarm = MediaPlayer.create(this ,R.raw.alarm);
        alarm.start();
    }
}