package com.example.theimpostor;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    final static String DB_NAME = "MYDB.db";
    final static String GROUP_TABLE = "gamegroup";
    final static String GROUP_NAME = "groupname";
    final static String GROUP_PLAYERS_NUM = "playersnum";
    final static String GROUP_IMPOSTORS_NUM = "impostornum";
    final static String GROUP_MINUTES = "minutes";
    final static String[] USERS_COLUMNS = {GROUP_NAME, GROUP_PLAYERS_NUM, GROUP_IMPOSTORS_NUM, GROUP_MINUTES};
    SQLiteDatabase db;

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, 1);
        db = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createGroupTableQuery =
                "create table " + GROUP_TABLE +
                        " (" + GROUP_NAME + " text," +
                        " " + GROUP_PLAYERS_NUM + " integer," +
                        " " + GROUP_IMPOSTORS_NUM + " integer," +
                        " " + GROUP_MINUTES + " integer);";

        Log.d("DBTEST", createGroupTableQuery);
        db.execSQL(createGroupTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + GROUP_NAME);
        onCreate(db);
    }

    public void insertNewGroup (Group group){
        db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GROUP_NAME, group.getGroupname());
        contentValues.put(GROUP_PLAYERS_NUM, group.getPlayersnum());
        contentValues.put(GROUP_IMPOSTORS_NUM, group.getImpostornum());
        contentValues.put(GROUP_MINUTES, group.getMinutes());
        db.insert(GROUP_TABLE, null, contentValues);
    }

    public ArrayList<Group> getAllGroups()
    {
        ArrayList<Group> groups = new ArrayList<>();
        db = getReadableDatabase();
        Cursor cursor = db.query(GROUP_TABLE, null, null,
                null, null, null, null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast())
        {
            String Groupname = cursor.getString(
                    (int) cursor.getColumnIndex(GROUP_NAME));
            int Playersnum = cursor.getInt(
                    (int)cursor.getColumnIndex(GROUP_PLAYERS_NUM));
            int Impostornum = cursor.getInt(
                    (int)cursor.getColumnIndex(GROUP_IMPOSTORS_NUM));
            int minutes = cursor.getInt(
                    (int)cursor.getColumnIndex(GROUP_MINUTES));

            Group group = new Group(Groupname, Playersnum, Impostornum, minutes);
            groups.add(group);
            cursor.moveToNext();
        }
        return groups;
    }

    public void deleteGroup(Group group)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(GROUP_TABLE, GROUP_NAME + " = '" + group.getGroupname() + "'", null);
    }

    public void updateGroup(Group group, String oldGroupname)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GROUP_NAME, group.getGroupname());
        contentValues.put(GROUP_PLAYERS_NUM, group.getPlayersnum());
        contentValues.put(GROUP_IMPOSTORS_NUM, group.getImpostornum());
        contentValues.put(GROUP_MINUTES, group.getMinutes());
        db.update(GROUP_TABLE, contentValues, GROUP_NAME + " = '" + oldGroupname + "'", null);
    }


}
