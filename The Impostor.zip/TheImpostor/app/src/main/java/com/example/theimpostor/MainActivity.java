package com.example.theimpostor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button instructions, new_game, new_group, saved_group, share;
    Dialog new_game_dialog;
    DBHelper dbHelper;
    private int notificationId = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DBHelper(this);

        getSupportActionBar().hide();

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.setStatusBarColor(this.getResources().getColor(R.color.black));

        notification();

        instructions = findViewById(R.id.instructions);
        new_game = findViewById(R.id.new_game);
        share = findViewById(R.id.share);

        instructions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Instructions.class);
                startActivity(intent);
            }
        });

        new_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Create_new_game_dialog();
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Hi! Let's play THE IMPOSTOR together!");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
    }

    public void Create_new_game_dialog(){
        new_game_dialog = new Dialog(this);
        new_game_dialog.setContentView(R.layout.new_game_layout);
        new_game_dialog.setTitle("NEW GAME");
        new_game_dialog.setCancelable(true);
        new_group = new_game_dialog.findViewById(R.id.new_group);
        saved_group = new_game_dialog.findViewById(R.id.saved_group);

        new_group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Group_setting.class);
                startActivity(intent);
            }
        });

        saved_group.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Saved_group.class);
                startActivity(intent);
            }
        });

        new_game_dialog.show();
    }

    public void notification(){
        Intent myIntent = new Intent(MainActivity.this , NotifyReceiver.class);
        myIntent.putExtra("notificationId", notificationId);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, 0, myIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
        Calendar start_time1 = Calendar.getInstance();
        start_time1.set(Calendar.SECOND, 0);
        start_time1.set(Calendar.MINUTE, 00);
        start_time1.set(Calendar.HOUR_OF_DAY, 8);
        long notify_start_time1 = start_time1.getTimeInMillis();

        alarmManager.set(AlarmManager.RTC_WAKEUP, notify_start_time1, pendingIntent);

        Calendar start_time2 = Calendar.getInstance();
        start_time2.set(Calendar.SECOND, 0);
        start_time2.set(Calendar.MINUTE, 00);
        start_time2.set(Calendar.HOUR_OF_DAY, 14);
        long notify_start_time2 = start_time2.getTimeInMillis();

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, notify_start_time2, 1000*60*60*24 , pendingIntent);

        Calendar start_time3 = Calendar.getInstance();
        start_time3.set(Calendar.SECOND, 0);
        start_time3.set(Calendar.MINUTE, 00);
        start_time3.set(Calendar.HOUR_OF_DAY, 20);
        long notify_start_time3 = start_time3.getTimeInMillis();

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, notify_start_time3, 1000*60*60*24 , pendingIntent);
    }
}