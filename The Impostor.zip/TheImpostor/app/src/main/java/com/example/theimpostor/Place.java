package com.example.theimpostor;

import java.io.Serializable;

public class Place implements Serializable {

    String place_name;
    Boolean checked;
    Boolean clue;

    public Place(String place_name) {
        this.place_name = place_name;
        this.checked = false;
        this.clue = false;
    }

    public String getPlace_name() {
        return place_name;
    }

    public void setPlace_name(String place_name) {
        this.place_name = place_name;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public Boolean getClue() {
        return clue;
    }

    public void setClue(Boolean clue) {
        this.clue = clue;
    }
}
